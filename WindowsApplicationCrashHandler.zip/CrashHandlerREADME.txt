Universal Crash Handler By IHobble

The client can be renamed to whatever you choose.

Drag all items to the directory of the application.
If there is no settings files with the program it will create them.

Directory files with spaces will cause this to not work.
names like "My Server" should be "MyServer"

I.E C:\Users\User\Desktop\Dev programs\Crash Handler\ WILL NOT WORK!
But C:\Users\User\Desktop\Dev-programs\Crash-Handler\ Will work.

This program monitors application crashes, it will restart programs that are "Not Responding".
If the monitored task completely closes this will restart it.

 Running multiple Handlers.
   Independent locations. 
     Copy the client to the desired location, name as desired, launch and complete first time setup.
   
   Same location.
     Copy and rename client, launch and complete first time setup.
	 To to edit clients with the editor put the clients name in the "CrashHandlerDependent.txt" file.

  ----Settings And Options----
  
  *Time is in seconds*

 +ForceRestartTime
What time the system forces a application shutdown for hard restarts. Runs on a 24hr clock. Avoid using 00:00 or 24:00. Single digit times should be [ x:xx] and time from 12:00 and on take all spaces [xx:xx]
Set as 99:99 to disable this feature.

 +RestartWaitTime
How long the system waits to recheck if the application is running after it attempts to restart. setting this too low may result in multiple instances of a application being opened. 
Default Is 60 seconds (1 Min).

 +StatusCheckWaitTime
 *Do Not go below 60 seconds with Force Restart Enabeled!*
How long the system waits to recheck after it detects that the application is running. 
Default Is 60 seconds (1 Min).

 +NoResponse
How long to wait for a application to start responding before forcing it to restart.
if a application stays unresponsive for X amount of time the client kills the process and after 1 min tells the Restart process to begin. This gives time for a crashed client to close before the next launch process.
times are in 10x. 3=30, 6=60, 12=120, ETC.

 +ApplicationName
The name of the application you want to keep running. Do NOT add .exe at the end of the program name. 

 +ApplicationType
What type of program it is. EXE, BAT, ETC. Dont add a dot ".".

 +Auto start
 *Use the options menu to change the auto start.
AutoStart is streamlined with the options menu. turn it on or off as desired.

 +Manually edit Windows startup file
In lame terms, its a shortcut to the windows startup file.

 +Create generic start file for editing
Builds a start file with a basic YOUR-VALUES type path for editing.

 
  ----HELP----
  
  +Failure to start. 
Delete the Settings folder then launch the application and do the first time setup process.
Be sure the directory doesnt have spacces in it.
Numerical settings with letters or other characters in them will cause a crash.


